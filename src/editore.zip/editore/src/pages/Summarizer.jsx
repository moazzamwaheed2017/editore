import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, Minimize2, BarChart3, Clock } from 'lucide-react';

const Summarizer = () => {
  const [inputText, setInputText] = useState('');
  const [summary, setSummary] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [summaryLength, setSummaryLength] = useState('medium');
  const [summaryType, setSummaryType] = useState('extractive');

  const lengthOptions = [
    { id: 'short', name: 'Short', description: '2-3 sentences', percentage: 25 },
    { id: 'medium', name: 'Medium', description: '4-6 sentences', percentage: 50 },
    { id: 'long', name: 'Long', description: '7-10 sentences', percentage: 75 }
  ];

  const typeOptions = [
    { id: 'extractive', name: 'Extractive', description: 'Key sentences from original' },
    { id: 'abstractive', name: 'Abstractive', description: 'Rewritten summary' }
  ];

  const handleSummarize = () => {
    if (!inputText.trim()) return;
    setIsProcessing(true);
    
    setTimeout(() => {
      const sentences = inputText.split('.').filter(s => s.trim().length > 0);
      const targetLength = Math.ceil(sentences.length * (lengthOptions.find(l => l.id === summaryLength)?.percentage / 100));
      const summarized = sentences.slice(0, targetLength).join('. ') + '.';
      setSummary(summarized);
      setIsProcessing(false);
    }, 3000);
  };

  const getReadingTime = (text) => {
    const wordsPerMinute = 200;
    const wordCount = text.split(' ').length;
    return Math.ceil(wordCount / wordsPerMinute);
  };

  const getCompressionRatio = () => {
    if (!inputText || !summary) return 0;
    return Math.round((1 - summary.length / inputText.length) * 100);
  };

  return (
    <div className="min-h-screen bg-primary pt-24 pb-16">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold text-text-primary mb-6">AI Summarizer</h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Transform long content into concise, meaningful summaries. 
            Choose your preferred length and summarization style.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-2xl p-6 shadow-lg"
          >
            <h3 className="text-lg font-semibold mb-4 text-text-primary">Summary Length</h3>
            <div className="grid grid-cols-3 gap-3">
              {lengthOptions.map((option) => (
                <motion.button
                  key={option.id}
                  onClick={() => setSummaryLength(option.id)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={`p-3 rounded-xl border-2 transition-all text-center ${
                    summaryLength === option.id
                      ? 'border-accent-blue bg-accent-blue/10 text-accent-blue'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-medium text-sm">{option.name}</div>
                  <div className="text-xs text-text-secondary mt-1">{option.description}</div>
                </motion.button>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-2xl p-6 shadow-lg"
          >
            <h3 className="text-lg font-semibold mb-4 text-text-primary">Summary Type</h3>
            <div className="grid grid-cols-2 gap-3">
              {typeOptions.map((option) => (
                <motion.button
                  key={option.id}
                  onClick={() => setSummaryType(option.id)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={`p-3 rounded-xl border-2 transition-all text-center ${
                    summaryType === option.id
                      ? 'border-accent-green bg-accent-green/10 text-accent-green'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-medium text-sm">{option.name}</div>
                  <div className="text-xs text-text-secondary mt-1">{option.description}</div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <h3 className="text-2xl font-semibold mb-6 text-text-primary">Original Content</h3>
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Paste your long-form content here to generate a summary..."
              className="w-full h-80 p-4 border border-gray-200 rounded-xl resize-none focus:ring-2 focus:ring-accent-blue focus:border-transparent transition-all"
            />
            <div className="flex justify-between items-center mt-4">
              <div className="flex gap-4 text-sm text-text-secondary">
                <span>{inputText.split(' ').filter(w => w.length > 0).length} words</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {getReadingTime(inputText)} min read
                </span>
              </div>
              <motion.button
                onClick={handleSummarize}
                disabled={!inputText.trim() || isProcessing}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-accent-blue to-accent-green text-white px-8 py-3 rounded-xl font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                <Minimize2 className={`w-5 h-5 ${isProcessing ? 'animate-pulse' : ''}`} />
                {isProcessing ? 'Summarizing...' : 'Summarize'}
              </motion.button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <h3 className="text-2xl font-semibold mb-6 text-text-primary">Summary</h3>
            
            {isProcessing && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center h-80"
              >
                <div className="relative mb-6">
                  <div className="w-20 h-20 border-4 border-accent-blue/20 rounded-full"></div>
                  <div className="absolute top-0 left-0 w-20 h-20 border-4 border-accent-blue border-t-transparent rounded-full animate-spin"></div>
                </div>
                <p className="text-text-secondary mb-4">Analyzing and condensing content...</p>
                <div className="w-64 bg-gray-200 rounded-full h-2">
                  <motion.div
                    className="bg-gradient-to-r from-accent-blue to-accent-green h-2 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 3, ease: 'easeInOut' }}
                  ></motion.div>
                </div>
              </motion.div>
            )}

            {summary && !isProcessing && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="h-64 p-4 bg-gray-50 rounded-xl border border-gray-200 overflow-y-auto">
                  <p className="text-text-primary leading-relaxed">{summary}</p>
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-blue-50 rounded-xl p-4 text-center">
                    <FileText className="w-6 h-6 text-accent-blue mx-auto mb-2" />
                    <p className="text-sm text-text-secondary mb-1">Words</p>
                    <p className="text-lg font-semibold text-text-primary">
                      {summary.split(' ').filter(w => w.length > 0).length}
                    </p>
                  </div>
                  <div className="bg-green-50 rounded-xl p-4 text-center">
                    <BarChart3 className="w-6 h-6 text-accent-green mx-auto mb-2" />
                    <p className="text-sm text-text-secondary mb-1">Compression</p>
                    <p className="text-lg font-semibold text-text-primary">{getCompressionRatio()}%</p>
                  </div>
                  <div className="bg-purple-50 rounded-xl p-4 text-center">
                    <Clock className="w-6 h-6 text-purple-500 mx-auto mb-2" />
                    <p className="text-sm text-text-secondary mb-1">Read Time</p>
                    <p className="text-lg font-semibold text-text-primary">{getReadingTime(summary)} min</p>
                  </div>
                </div>
              </motion.div>
            )}

            {!summary && !isProcessing && (
              <div className="flex flex-col items-center justify-center h-80 text-gray-400">
                <FileText className="w-16 h-16 mb-4" />
                <p>Your summary will appear here</p>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Summarizer;
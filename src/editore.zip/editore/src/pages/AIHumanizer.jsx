import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Bot, Shuffle, Gauge } from 'lucide-react';

const AIHumanizer = () => {
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [humanizationLevel, setHumanizationLevel] = useState('balanced');
  const [beforeScore, setBeforeScore] = useState(0);
  const [afterScore, setAfterScore] = useState(0);

  const levels = [
    { id: 'light', name: 'Light', description: 'Subtle improvements', intensity: 25 },
    { id: 'balanced', name: 'Balanced', description: 'Optimal human-like', intensity: 50 },
    { id: 'aggressive', name: 'Aggressive', description: 'Maximum humanization', intensity: 75 }
  ];

  const handleHumanize = () => {
    if (!inputText.trim()) return;
    setIsProcessing(true);
    
    // Simulate AI detection score for input
    const initialAIScore = Math.floor(Math.random() * 40) + 60; // 60-100% AI
    setBeforeScore(initialAIScore);
    
    setTimeout(() => {
      const humanizedText = generateHumanizedText(inputText, humanizationLevel);
      setOutputText(humanizedText);
      
      // Calculate improved score based on humanization level
      const improvement = levels.find(l => l.id === humanizationLevel)?.intensity || 50;
      const finalScore = Math.max(5, initialAIScore - improvement);
      setAfterScore(finalScore);
      
      setIsProcessing(false);
    }, 3500);
  };

  const generateHumanizedText = (text, level) => {
    let humanized = text;
    
    switch (level) {
      case 'light':
        humanized = text.replace(/\b(very|really|quite)\b/g, 'somewhat');
        break;
      case 'balanced':
        humanized = text
          .replace(/\b(utilize)\b/g, 'use')
          .replace(/\b(facilitate)\b/g, 'help')
          .replace(/\b(demonstrate)\b/g, 'show');
        break;
      case 'aggressive':
        humanized = text
          .replace(/\b(furthermore)\b/g, 'also')
          .replace(/\b(therefore)\b/g, 'so')
          .replace(/\b(subsequently)\b/g, 'then')
          .replace(/\b(in conclusion)\b/g, 'to wrap up');
        break;
    }
    
    return humanized;
  };

  const getScoreColor = (score) => {
    if (score <= 30) return 'text-green-600';
    if (score <= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreLabel = (score) => {
    if (score <= 30) return 'Human-like';
    if (score <= 60) return 'Mixed';
    return 'AI-like';
  };

  return (
    <div className="min-h-screen bg-primary pt-24 pb-16">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold text-text-primary mb-6">AI Humanizer</h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Transform AI-generated content into natural, human-like writing. 
            Bypass AI detectors while maintaining quality and meaning.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl p-8 shadow-lg mb-8"
        >
          <h3 className="text-xl font-semibold mb-4 text-text-primary">Humanization Level</h3>
          <div className="grid grid-cols-3 gap-4">
            {levels.map((level) => (
              <motion.button
                key={level.id}
                onClick={() => setHumanizationLevel(level.id)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`p-4 rounded-xl border-2 transition-all ${
                  humanizationLevel === level.id
                    ? 'border-accent-blue bg-accent-blue/10 text-accent-blue'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="font-medium mb-1">{level.name}</div>
                <div className="text-sm text-text-secondary mb-2">{level.description}</div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-accent-blue to-accent-green h-2 rounded-full transition-all"
                    style={{ width: `${level.intensity}%` }}
                  ></div>
                </div>
              </motion.button>
            ))}
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <div className="flex items-center gap-3 mb-6">
              <Bot className="w-6 h-6 text-red-500" />
              <h3 className="text-2xl font-semibold text-text-primary">AI-Generated Text</h3>
            </div>
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Paste your AI-generated content here to humanize it..."
              className="w-full h-80 p-4 border border-gray-200 rounded-xl resize-none focus:ring-2 focus:ring-accent-blue focus:border-transparent transition-all"
            />
            <div className="flex justify-between items-center mt-4">
              <div className="flex items-center gap-4">
                <span className="text-sm text-text-secondary">{inputText.length} characters</span>
                {beforeScore > 0 && (
                  <div className="flex items-center gap-2">
                    <Gauge className="w-4 h-4 text-text-secondary" />
                    <span className={`text-sm font-medium ${getScoreColor(beforeScore)}`}>
                      {beforeScore}% AI-like
                    </span>
                  </div>
                )}
              </div>
              <motion.button
                onClick={handleHumanize}
                disabled={!inputText.trim() || isProcessing}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-accent-blue to-accent-green text-white px-8 py-3 rounded-xl font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                <Shuffle className={`w-5 h-5 ${isProcessing ? 'animate-spin' : ''}`} />
                {isProcessing ? 'Humanizing...' : 'Humanize'}
              </motion.button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <div className="flex items-center gap-3 mb-6">
              <User className="w-6 h-6 text-green-500" />
              <h3 className="text-2xl font-semibold text-text-primary">Humanized Text</h3>
            </div>
            
            {isProcessing && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center h-80"
              >
                <div className="relative mb-6">
                  <div className="w-20 h-20 border-4 border-accent-green/20 rounded-full"></div>
                  <div className="absolute top-0 left-0 w-20 h-20 border-4 border-accent-green border-t-transparent rounded-full animate-spin"></div>
                </div>
                <p className="text-text-secondary mb-4">Transforming to human-like writing...</p>
                <div className="w-64 bg-gray-200 rounded-full h-2">
                  <motion.div
                    className="bg-gradient-to-r from-accent-blue to-accent-green h-2 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 3.5, ease: 'easeInOut' }}
                  ></motion.div>
                </div>
              </motion.div>
            )}

            {outputText && !isProcessing && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-4"
              >
                <div className="h-80 p-4 bg-green-50 rounded-xl border border-green-200 overflow-y-auto">
                  <p className="text-text-primary leading-relaxed">{outputText}</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-text-secondary">{outputText.length} characters</span>
                  <div className="flex items-center gap-2">
                    <Gauge className="w-4 h-4 text-text-secondary" />
                    <span className={`text-sm font-medium ${getScoreColor(afterScore)}`}>
                      {afterScore}% {getScoreLabel(afterScore)}
                    </span>
                  </div>
                </div>
              </motion.div>
            )}

            {!outputText && !isProcessing && (
              <div className="flex flex-col items-center justify-center h-80 text-gray-400">
                <User className="w-16 h-16 mb-4" />
                <p>Your humanized text will appear here</p>
              </div>
            )}
          </motion.div>
        </div>

        {beforeScore > 0 && afterScore > 0 && !isProcessing && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <h3 className="text-2xl font-semibold mb-6 text-text-primary">Humanization Results</h3>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-red-600 mb-2">{beforeScore}%</div>
                <p className="text-sm text-text-secondary">Before (AI-like)</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">{afterScore}%</div>
                <p className="text-sm text-text-secondary">After ({getScoreLabel(afterScore)})</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent-blue mb-2">{beforeScore - afterScore}%</div>
                <p className="text-sm text-text-secondary">Improvement</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent-green mb-2">98%</div>
                <p className="text-sm text-text-secondary">Bypass Rate</p>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default AIHumanizer;
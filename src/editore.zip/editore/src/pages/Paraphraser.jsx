import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { RefreshCw, Copy, Download } from 'lucide-react';

const Paraphraser = () => {
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [mode, setMode] = useState('standard');

  const modes = [
    { id: 'standard', name: 'Standard', description: 'Balanced rewriting' },
    { id: 'fluency', name: 'Fluency', description: 'Improve readability' },
    { id: 'creative', name: 'Creative', description: 'More creative variations' },
    { id: 'formal', name: 'Formal', description: 'Professional tone' }
  ];

  const handleParaphrase = () => {
    if (!inputText.trim()) return;
    setIsProcessing(true);
    
    setTimeout(() => {
      const paraphrased = generateParaphrase(inputText, mode);
      setOutputText(paraphrased);
      setIsProcessing(false);
    }, 2000);
  };

  const generateParaphrase = (text, selectedMode) => {
    const variations = {
      standard: text.replace(/\b(the|and|or|but)\b/g, (match) => {
        const replacements = { 'the': 'a', 'and': 'plus', 'or': 'alternatively', 'but': 'however' };
        return replacements[match] || match;
      }),
      fluency: text.replace(/\b\w+\b/g, (word) => word.length > 6 ? word.slice(0, -2) + 'ed' : word),
      creative: text.split(' ').reverse().join(' '),
      formal: text.replace(/\b(good|bad|big|small)\b/g, (match) => {
        const formal = { 'good': 'excellent', 'bad': 'inadequate', 'big': 'substantial', 'small': 'minimal' };
        return formal[match] || match;
      })
    };
    return variations[selectedMode] || text;
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(outputText);
  };

  return (
    <div className="min-h-screen bg-primary pt-24 pb-16">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold text-text-primary mb-6">AI Paraphraser</h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Rewrite your content with AI-powered paraphrasing. Choose from multiple modes to 
            match your writing style and improve clarity.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl p-8 shadow-lg mb-8"
        >
          <h3 className="text-xl font-semibold mb-4 text-text-primary">Paraphrasing Mode</h3>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {modes.map((modeOption) => (
              <motion.button
                key={modeOption.id}
                onClick={() => setMode(modeOption.id)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`p-4 rounded-xl border-2 transition-all ${
                  mode === modeOption.id
                    ? 'border-accent-blue bg-accent-blue/10 text-accent-blue'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="font-medium mb-1">{modeOption.name}</div>
                <div className="text-sm text-text-secondary">{modeOption.description}</div>
              </motion.button>
            ))}
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <h3 className="text-2xl font-semibold mb-6 text-text-primary">Original Text</h3>
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Enter the text you want to paraphrase..."
              className="w-full h-80 p-4 border border-gray-200 rounded-xl resize-none focus:ring-2 focus:ring-accent-blue focus:border-transparent transition-all"
            />
            <div className="flex justify-between items-center mt-4">
              <span className="text-sm text-text-secondary">{inputText.length} characters</span>
              <motion.button
                onClick={handleParaphrase}
                disabled={!inputText.trim() || isProcessing}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-accent-blue to-accent-green text-white px-8 py-3 rounded-xl font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                <RefreshCw className={`w-5 h-5 ${isProcessing ? 'animate-spin' : ''}`} />
                {isProcessing ? 'Paraphrasing...' : 'Paraphrase'}
              </motion.button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-semibold text-text-primary">Paraphrased Text</h3>
              {outputText && (
                <div className="flex gap-2">
                  <motion.button
                    onClick={copyToClipboard}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 text-accent-blue hover:bg-accent-blue/10 rounded-lg transition-colors"
                  >
                    <Copy className="w-5 h-5" />
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 text-accent-blue hover:bg-accent-blue/10 rounded-lg transition-colors"
                  >
                    <Download className="w-5 h-5" />
                  </motion.button>
                </div>
              )}
            </div>
            
            {isProcessing && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center h-80"
              >
                <div className="relative mb-6">
                  <div className="w-16 h-16 border-4 border-accent-green/20 rounded-full"></div>
                  <div className="absolute top-0 left-0 w-16 h-16 border-4 border-accent-green border-t-transparent rounded-full animate-spin"></div>
                </div>
                <p className="text-text-secondary mb-4">Rewriting your content...</p>
                <div className="w-64 bg-gray-200 rounded-full h-2">
                  <motion.div
                    className="bg-gradient-to-r from-accent-blue to-accent-green h-2 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 2, ease: 'easeInOut' }}
                  ></motion.div>
                </div>
              </motion.div>
            )}

            {outputText && !isProcessing && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="h-80 p-4 bg-gray-50 rounded-xl border border-gray-200 overflow-y-auto"
              >
                <p className="text-text-primary leading-relaxed">{outputText}</p>
              </motion.div>
            )}

            {!outputText && !isProcessing && (
              <div className="flex flex-col items-center justify-center h-80 text-gray-400">
                <RefreshCw className="w-16 h-16 mb-4" />
                <p>Your paraphrased text will appear here</p>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Paraphraser;
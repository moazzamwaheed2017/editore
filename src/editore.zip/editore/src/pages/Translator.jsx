import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Languages, ArrowRightLeft, Volume2, Copy } from 'lucide-react';

const Translator = () => {
  const [sourceText, setSourceText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [sourceLang, setSourceLang] = useState('en');
  const [targetLang, setTargetLang] = useState('es');
  const [isTranslating, setIsTranslating] = useState(false);

  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'es', name: 'Spanish', flag: '🇪🇸' },
    { code: 'fr', name: 'French', flag: '🇫🇷' },
    { code: 'de', name: 'German', flag: '🇩🇪' },
    { code: 'it', name: 'Italian', flag: '🇮🇹' },
    { code: 'pt', name: 'Portuguese', flag: '🇵🇹' },
    { code: 'ru', name: 'Russian', flag: '🇷🇺' },
    { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
    { code: 'ko', name: 'Korean', flag: '🇰🇷' },
    { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
    { code: 'ar', name: 'Arabic', flag: '🇸🇦' },
    { code: 'hi', name: 'Hindi', flag: '🇮🇳' }
  ];

  const handleTranslate = () => {
    if (!sourceText.trim()) return;
    setIsTranslating(true);
    
    setTimeout(() => {
      // Mock translation - in real app, this would call a translation API
      const mockTranslations = {
        'en-es': sourceText.replace(/hello/gi, 'hola').replace(/world/gi, 'mundo'),
        'en-fr': sourceText.replace(/hello/gi, 'bonjour').replace(/world/gi, 'monde'),
        'en-de': sourceText.replace(/hello/gi, 'hallo').replace(/world/gi, 'welt'),
        'es-en': sourceText.replace(/hola/gi, 'hello').replace(/mundo/gi, 'world')
      };
      
      const translationKey = `${sourceLang}-${targetLang}`;
      const translated = mockTranslations[translationKey] || `[Translated from ${sourceLang} to ${targetLang}] ${sourceText}`;
      
      setTranslatedText(translated);
      setIsTranslating(false);
    }, 2000);
  };

  const swapLanguages = () => {
    setSourceLang(targetLang);
    setTargetLang(sourceLang);
    setSourceText(translatedText);
    setTranslatedText(sourceText);
  };

  const speakText = (text, lang) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      speechSynthesis.speak(utterance);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
  };

  const getLanguageByCode = (code) => {
    return languages.find(lang => lang.code === code);
  };

  return (
    <div className="min-h-screen bg-primary pt-24 pb-16">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold text-text-primary mb-6">AI Translator</h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Break language barriers with AI-powered translation. 
            Translate text accurately across 100+ languages with context awareness.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl p-8 shadow-lg mb-8"
        >
          <div className="flex items-center justify-center gap-8">
            <div className="flex-1">
              <label className="block text-sm font-medium text-text-primary mb-3">From</label>
              <select
                value={sourceLang}
                onChange={(e) => setSourceLang(e.target.value)}
                className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-accent-blue focus:border-transparent transition-all"
              >
                {languages.map((lang) => (
                  <option key={lang.code} value={lang.code}>
                    {lang.flag} {lang.name}
                  </option>
                ))}
              </select>
            </div>
            
            <motion.button
              onClick={swapLanguages}
              whileHover={{ scale: 1.1, rotate: 180 }}
              whileTap={{ scale: 0.9 }}
              className="mt-6 p-3 bg-accent-blue/10 text-accent-blue rounded-full hover:bg-accent-blue/20 transition-colors"
            >
              <ArrowRightLeft className="w-6 h-6" />
            </motion.button>
            
            <div className="flex-1">
              <label className="block text-sm font-medium text-text-primary mb-3">To</label>
              <select
                value={targetLang}
                onChange={(e) => setTargetLang(e.target.value)}
                className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-accent-blue focus:border-transparent transition-all"
              >
                {languages.map((lang) => (
                  <option key={lang.code} value={lang.code}>
                    {lang.flag} {lang.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{getLanguageByCode(sourceLang)?.flag}</span>
                <h3 className="text-2xl font-semibold text-text-primary">
                  {getLanguageByCode(sourceLang)?.name}
                </h3>
              </div>
              {sourceText && (
                <div className="flex gap-2">
                  <motion.button
                    onClick={() => speakText(sourceText, sourceLang)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 text-accent-blue hover:bg-accent-blue/10 rounded-lg transition-colors"
                  >
                    <Volume2 className="w-5 h-5" />
                  </motion.button>
                  <motion.button
                    onClick={() => copyToClipboard(sourceText)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 text-accent-blue hover:bg-accent-blue/10 rounded-lg transition-colors"
                  >
                    <Copy className="w-5 h-5" />
                  </motion.button>
                </div>
              )}
            </div>
            
            <textarea
              value={sourceText}
              onChange={(e) => setSourceText(e.target.value)}
              placeholder="Enter text to translate..."
              className="w-full h-80 p-4 border border-gray-200 rounded-xl resize-none focus:ring-2 focus:ring-accent-blue focus:border-transparent transition-all text-lg"
            />
            
            <div className="flex justify-between items-center mt-4">
              <span className="text-sm text-text-secondary">{sourceText.length} characters</span>
              <motion.button
                onClick={handleTranslate}
                disabled={!sourceText.trim() || isTranslating}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-accent-blue to-accent-green text-white px-8 py-3 rounded-xl font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                <Languages className={`w-5 h-5 ${isTranslating ? 'animate-pulse' : ''}`} />
                {isTranslating ? 'Translating...' : 'Translate'}
              </motion.button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{getLanguageByCode(targetLang)?.flag}</span>
                <h3 className="text-2xl font-semibold text-text-primary">
                  {getLanguageByCode(targetLang)?.name}
                </h3>
              </div>
              {translatedText && (
                <div className="flex gap-2">
                  <motion.button
                    onClick={() => speakText(translatedText, targetLang)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 text-accent-blue hover:bg-accent-blue/10 rounded-lg transition-colors"
                  >
                    <Volume2 className="w-5 h-5" />
                  </motion.button>
                  <motion.button
                    onClick={() => copyToClipboard(translatedText)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 text-accent-blue hover:bg-accent-blue/10 rounded-lg transition-colors"
                  >
                    <Copy className="w-5 h-5" />
                  </motion.button>
                </div>
              )}
            </div>
            
            {isTranslating && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center h-80"
              >
                <div className="relative mb-6">
                  <div className="w-16 h-16 border-4 border-accent-green/20 rounded-full"></div>
                  <div className="absolute top-0 left-0 w-16 h-16 border-4 border-accent-green border-t-transparent rounded-full animate-spin"></div>
                </div>
                <p className="text-text-secondary mb-4">Translating your text...</p>
                <div className="w-64 bg-gray-200 rounded-full h-2">
                  <motion.div
                    className="bg-gradient-to-r from-accent-blue to-accent-green h-2 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 2, ease: 'easeInOut' }}
                  ></motion.div>
                </div>
              </motion.div>
            )}

            {translatedText && !isTranslating && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="h-80 p-4 bg-green-50 rounded-xl border border-green-200 overflow-y-auto"
              >
                <p className="text-text-primary leading-relaxed text-lg">{translatedText}</p>
              </motion.div>
            )}

            {!translatedText && !isTranslating && (
              <div className="flex flex-col items-center justify-center h-80 text-gray-400">
                <Languages className="w-16 h-16 mb-4" />
                <p>Translation will appear here</p>
              </div>
            )}
            
            {translatedText && !isTranslating && (
              <div className="flex justify-between items-center mt-4">
                <span className="text-sm text-text-secondary">{translatedText.length} characters</span>
                <div className="flex items-center gap-2 text-sm text-green-600">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  Translation complete
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Translator;
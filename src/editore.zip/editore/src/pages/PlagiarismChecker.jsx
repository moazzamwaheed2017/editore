import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Shield, AlertTriangle, CheckCircle, ExternalLink } from 'lucide-react';

const PlagiarismChecker = () => {
  const [text, setText] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [results, setResults] = useState(null);

  const handleCheck = () => {
    if (!text.trim()) return;
    setIsScanning(true);
    
    setTimeout(() => {
      const mockResults = {
        overallScore: Math.floor(Math.random() * 30) + 70,
        totalSources: Math.floor(Math.random() * 5) + 1,
        matches: [
          {
            id: 1,
            similarity: 85,
            source: 'Wikipedia - Artificial Intelligence',
            url: 'https://en.wikipedia.org/wiki/Artificial_intelligence',
            matchedText: 'Artificial intelligence is intelligence demonstrated by machines',
            type: 'exact'
          },
          {
            id: 2,
            similarity: 72,
            source: 'MIT Technology Review',
            url: 'https://www.technologyreview.com',
            matchedText: 'Machine learning algorithms process vast amounts of data',
            type: 'paraphrase'
          },
          {
            id: 3,
            similarity: 68,
            source: 'Stanford AI Research',
            url: 'https://ai.stanford.edu',
            matchedText: 'Neural networks mimic human brain functionality',
            type: 'similar'
          }
        ]
      };
      setResults(mockResults);
      setIsScanning(false);
    }, 4000);
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600 bg-green-50';
    if (score >= 70) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  const getMatchTypeIcon = (type) => {
    switch (type) {
      case 'exact': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'paraphrase': return <Search className="w-4 h-4 text-yellow-500" />;
      case 'similar': return <CheckCircle className="w-4 h-4 text-blue-500" />;
      default: return <Search className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-primary pt-24 pb-16">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold text-text-primary mb-6">Plagiarism Checker</h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Ensure originality with our advanced plagiarism detection. 
            Scan billions of web pages, academic papers, and publications.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2 bg-white rounded-2xl p-8 shadow-lg"
          >
            <h3 className="text-2xl font-semibold mb-6 text-text-primary">Document to Check</h3>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Paste your content here to check for plagiarism across billions of sources..."
              className="w-full h-96 p-4 border border-gray-200 rounded-xl resize-none focus:ring-2 focus:ring-accent-blue focus:border-transparent transition-all"
            />
            <div className="flex justify-between items-center mt-4">
              <div className="flex gap-4 text-sm text-text-secondary">
                <span>{text.length} characters</span>
                <span>{text.split(' ').filter(word => word.length > 0).length} words</span>
              </div>
              <motion.button
                onClick={handleCheck}
                disabled={!text.trim() || isScanning}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-accent-blue to-accent-green text-white px-8 py-3 rounded-xl font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                <Shield className={`w-5 h-5 ${isScanning ? 'animate-pulse' : ''}`} />
                {isScanning ? 'Scanning...' : 'Check Plagiarism'}
              </motion.button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <h3 className="text-2xl font-semibold mb-6 text-text-primary">Originality Score</h3>
            
            {isScanning && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center h-64"
              >
                <div className="relative mb-6">
                  <div className="w-24 h-24 border-4 border-accent-blue/20 rounded-full"></div>
                  <div className="absolute top-0 left-0 w-24 h-24 border-4 border-accent-blue border-t-transparent rounded-full animate-spin"></div>
                </div>
                <p className="text-text-secondary mb-4">Scanning billions of sources...</p>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <motion.div
                    className="bg-gradient-to-r from-accent-blue to-accent-green h-2 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 4, ease: 'easeInOut' }}
                  ></motion.div>
                </div>
              </motion.div>
            )}

            {results && !isScanning && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="space-y-6"
              >
                <div className="text-center">
                  <div className={`inline-flex items-center justify-center w-32 h-32 rounded-full text-4xl font-bold ${getScoreColor(results.overallScore)}`}>
                    {results.overallScore}%
                  </div>
                  <p className="mt-4 text-lg font-medium text-text-primary">
                    {results.overallScore >= 90 ? 'Highly Original' : 
                     results.overallScore >= 70 ? 'Mostly Original' : 'Needs Review'}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 rounded-xl p-4 text-center">
                    <p className="text-sm text-text-secondary mb-1">Sources Checked</p>
                    <p className="text-2xl font-bold text-text-primary">2.5B+</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-4 text-center">
                    <p className="text-sm text-text-secondary mb-1">Matches Found</p>
                    <p className="text-2xl font-bold text-text-primary">{results.totalSources}</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold text-text-primary">Detection Summary</h4>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span>Exact matches: {results.matches.filter(m => m.type === 'exact').length}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <span>Paraphrased: {results.matches.filter(m => m.type === 'paraphrase').length}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <span>Similar content: {results.matches.filter(m => m.type === 'similar').length}</span>
                  </div>
                </div>
              </motion.div>
            )}

            {!results && !isScanning && (
              <div className="flex flex-col items-center justify-center h-64 text-gray-400">
                <Shield className="w-16 h-16 mb-4" />
                <p>Your originality score will appear here</p>
              </div>
            )}
          </motion.div>
        </div>

        {results && !isScanning && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mt-8 bg-white rounded-2xl p-8 shadow-lg"
          >
            <h3 className="text-2xl font-semibold mb-6 text-text-primary">Detailed Matches</h3>
            <div className="space-y-4">
              {results.matches.map((match, index) => (
                <motion.div
                  key={match.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-3">
                      {getMatchTypeIcon(match.type)}
                      <div>
                        <h4 className="font-semibold text-text-primary">{match.source}</h4>
                        <p className="text-sm text-text-secondary capitalize">{match.type} match</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-red-600">{match.similarity}%</div>
                      <motion.a
                        href={match.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        whileHover={{ scale: 1.05 }}
                        className="inline-flex items-center gap-1 text-sm text-accent-blue hover:underline mt-1"
                      >
                        View Source <ExternalLink className="w-3 h-3" />
                      </motion.a>
                    </div>
                  </div>
                  <div className="bg-red-50 border-l-4 border-red-400 p-4 rounded">
                    <p className="text-text-primary italic">"{match.matchedText}"</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default PlagiarismChecker;
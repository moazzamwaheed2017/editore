import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Scan, CheckCircle, AlertTriangle } from 'lucide-react';

const AIDetector = () => {
  const [text, setText] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [result, setResult] = useState(null);

  const handleScan = () => {
    if (!text.trim()) return;
    setIsScanning(true);
    
    setTimeout(() => {
      const aiProbability = Math.floor(Math.random() * 100);
      setResult({
        probability: aiProbability,
        isAI: aiProbability > 50,
        confidence: aiProbability > 70 ? 'High' : aiProbability > 40 ? 'Medium' : 'Low'
      });
      setIsScanning(false);
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-primary pt-24 pb-16">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold text-text-primary mb-6">AI Content Detector</h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Detect AI-generated content with advanced machine learning algorithms. 
            Get instant analysis of text authenticity and confidence scores.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <h3 className="text-2xl font-semibold mb-6 text-text-primary">Input Text</h3>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Paste your text here to analyze for AI-generated content..."
              className="w-full h-80 p-4 border border-gray-200 rounded-xl resize-none focus:ring-2 focus:ring-accent-blue focus:border-transparent transition-all"
            />
            <div className="flex justify-between items-center mt-4">
              <span className="text-sm text-text-secondary">{text.length} characters</span>
              <motion.button
                onClick={handleScan}
                disabled={!text.trim() || isScanning}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-accent-blue to-accent-green text-white px-8 py-3 rounded-xl font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                <Scan className={`w-5 h-5 ${isScanning ? 'animate-spin' : ''}`} />
                {isScanning ? 'Scanning...' : 'Detect AI'}
              </motion.button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <h3 className="text-2xl font-semibold mb-6 text-text-primary">Analysis Results</h3>
            
            {isScanning && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center h-80"
              >
                <div className="relative">
                  <div className="w-20 h-20 border-4 border-accent-blue/20 rounded-full"></div>
                  <div className="absolute top-0 left-0 w-20 h-20 border-4 border-accent-blue border-t-transparent rounded-full animate-spin"></div>
                </div>
                <p className="mt-6 text-text-secondary">Analyzing content for AI patterns...</p>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-4">
                  <motion.div
                    className="bg-gradient-to-r from-accent-blue to-accent-green h-2 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 3, ease: 'easeInOut' }}
                  ></motion.div>
                </div>
              </motion.div>
            )}

            {result && !isScanning && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="space-y-6"
              >
                <div className="text-center">
                  <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium ${
                    result.isAI ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
                  }`}>
                    {result.isAI ? <AlertTriangle className="w-4 h-4" /> : <CheckCircle className="w-4 h-4" />}
                    {result.isAI ? 'Likely AI Generated' : 'Likely Human Written'}
                  </div>
                </div>

                <div className="bg-gray-50 rounded-xl p-6">
                  <div className="flex justify-between items-center mb-4">
                    <span className="font-medium text-text-primary">AI Probability</span>
                    <span className="text-2xl font-bold text-text-primary">{result.probability}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <motion.div
                      className={`h-3 rounded-full ${
                        result.probability > 70 ? 'bg-red-500' : 
                        result.probability > 40 ? 'bg-yellow-500' : 'bg-green-500'
                      }`}
                      initial={{ width: 0 }}
                      animate={{ width: `${result.probability}%` }}
                      transition={{ duration: 1, ease: 'easeOut' }}
                    ></motion.div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 rounded-xl p-4 text-center">
                    <p className="text-sm text-text-secondary mb-1">Confidence Level</p>
                    <p className="text-lg font-semibold text-text-primary">{result.confidence}</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-4 text-center">
                    <p className="text-sm text-text-secondary mb-1">Analysis Time</p>
                    <p className="text-lg font-semibold text-text-primary">2.3s</p>
                  </div>
                </div>
              </motion.div>
            )}

            {!result && !isScanning && (
              <div className="flex flex-col items-center justify-center h-80 text-gray-400">
                <Scan className="w-16 h-16 mb-4" />
                <p>Enter text and click "Detect AI" to start analysis</p>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default AIDetector;
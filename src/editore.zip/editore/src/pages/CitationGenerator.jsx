import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Copy, Download, Plus, Trash2 } from 'lucide-react';

const CitationGenerator = () => {
  const [citationStyle, setCitationStyle] = useState('apa');
  const [sourceType, setSourceType] = useState('website');
  const [sources, setSources] = useState([]);
  const [currentSource, setCurrentSource] = useState({
    title: '',
    author: '',
    url: '',
    date: '',
    publisher: ''
  });

  const styles = [
    { id: 'apa', name: 'APA 7th', description: 'American Psychological Association' },
    { id: 'mla', name: 'MLA 9th', description: 'Modern Language Association' },
    { id: 'chicago', name: 'Chicago', description: 'Chicago Manual of Style' },
    { id: 'harvard', name: 'Harvard', description: 'Harvard Referencing Style' }
  ];

  const sourceTypes = [
    { id: 'website', name: 'Website', fields: ['title', 'author', 'url', 'date', 'publisher'] },
    { id: 'book', name: 'Book', fields: ['title', 'author', 'publisher', 'date', 'pages'] },
    { id: 'journal', name: 'Journal', fields: ['title', 'author', 'journal', 'volume', 'date'] },
    { id: 'newspaper', name: 'Newspaper', fields: ['title', 'author', 'newspaper', 'date', 'url'] }
  ];

  const generateCitation = (source, style) => {
    const { title, author, url, date, publisher } = source;
    
    switch (style) {
      case 'apa':
        return `${author} (${date}). ${title}. ${publisher}. ${url}`;
      case 'mla':
        return `${author}. "${title}." ${publisher}, ${date}, ${url}.`;
      case 'chicago':
        return `${author}. "${title}." ${publisher}. ${date}. ${url}.`;
      case 'harvard':
        return `${author} (${date}) '${title}', ${publisher}, available at: ${url}.`;
      default:
        return `${author} (${date}). ${title}. ${publisher}. ${url}`;
    }
  };

  const addSource = () => {
    if (!currentSource.title || !currentSource.author) return;
    
    const newSource = {
      id: Date.now(),
      ...currentSource,
      citation: generateCitation(currentSource, citationStyle)
    };
    
    setSources([...sources, newSource]);
    setCurrentSource({ title: '', author: '', url: '', date: '', publisher: '' });
  };

  const removeSource = (id) => {
    setSources(sources.filter(source => source.id !== id));
  };

  const copyAllCitations = () => {
    const allCitations = sources.map(source => source.citation).join('\n\n');
    navigator.clipboard.writeText(allCitations);
  };

  const downloadCitations = () => {
    const allCitations = sources.map(source => source.citation).join('\n\n');
    const blob = new Blob([allCitations], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `citations-${citationStyle}.txt`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-primary pt-24 pb-16">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold text-text-primary mb-6">Citation Generator</h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Generate accurate citations in APA, MLA, Chicago, and Harvard styles. 
            Perfect for academic papers, research, and professional writing.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-2xl p-6 shadow-lg"
          >
            <h3 className="text-lg font-semibold mb-4 text-text-primary">Citation Style</h3>
            <div className="grid grid-cols-2 gap-3">
              {styles.map((style) => (
                <motion.button
                  key={style.id}
                  onClick={() => setCitationStyle(style.id)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={`p-3 rounded-xl border-2 transition-all text-left ${
                    citationStyle === style.id
                      ? 'border-accent-blue bg-accent-blue/10 text-accent-blue'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-medium text-sm">{style.name}</div>
                  <div className="text-xs text-text-secondary mt-1">{style.description}</div>
                </motion.button>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-2xl p-6 shadow-lg"
          >
            <h3 className="text-lg font-semibold mb-4 text-text-primary">Source Type</h3>
            <div className="grid grid-cols-2 gap-3">
              {sourceTypes.map((type) => (
                <motion.button
                  key={type.id}
                  onClick={() => setSourceType(type.id)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={`p-3 rounded-xl border-2 transition-all text-center ${
                    sourceType === type.id
                      ? 'border-accent-green bg-accent-green/10 text-accent-green'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-medium text-sm">{type.name}</div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <h3 className="text-2xl font-semibold mb-6 text-text-primary">Add Source</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">Title *</label>
                <input
                  type="text"
                  value={currentSource.title}
                  onChange={(e) => setCurrentSource({...currentSource, title: e.target.value})}
                  placeholder="Enter the title of the source"
                  className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-accent-blue focus:border-transparent transition-all"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">Author *</label>
                <input
                  type="text"
                  value={currentSource.author}
                  onChange={(e) => setCurrentSource({...currentSource, author: e.target.value})}
                  placeholder="Enter the author's name"
                  className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-accent-blue focus:border-transparent transition-all"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">URL</label>
                <input
                  type="url"
                  value={currentSource.url}
                  onChange={(e) => setCurrentSource({...currentSource, url: e.target.value})}
                  placeholder="https://example.com"
                  className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-accent-blue focus:border-transparent transition-all"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">Date</label>
                  <input
                    type="date"
                    value={currentSource.date}
                    onChange={(e) => setCurrentSource({...currentSource, date: e.target.value})}
                    className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-accent-blue focus:border-transparent transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">Publisher</label>
                  <input
                    type="text"
                    value={currentSource.publisher}
                    onChange={(e) => setCurrentSource({...currentSource, publisher: e.target.value})}
                    placeholder="Publisher name"
                    className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-accent-blue focus:border-transparent transition-all"
                  />
                </div>
              </div>
              <motion.button
                onClick={addSource}
                disabled={!currentSource.title || !currentSource.author}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full bg-gradient-to-r from-accent-blue to-accent-green text-white py-3 rounded-xl font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Add Citation
              </motion.button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-semibold text-text-primary">Generated Citations</h3>
              {sources.length > 0 && (
                <div className="flex gap-2">
                  <motion.button
                    onClick={copyAllCitations}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 text-accent-blue hover:bg-accent-blue/10 rounded-lg transition-colors"
                  >
                    <Copy className="w-5 h-5" />
                  </motion.button>
                  <motion.button
                    onClick={downloadCitations}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 text-accent-blue hover:bg-accent-blue/10 rounded-lg transition-colors"
                  >
                    <Download className="w-5 h-5" />
                  </motion.button>
                </div>
              )}
            </div>
            
            {sources.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 text-gray-400">
                <BookOpen className="w-16 h-16 mb-4" />
                <p>Your citations will appear here</p>
              </div>
            ) : (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {sources.map((source, index) => (
                  <motion.div
                    key={source.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="p-4 border border-gray-200 rounded-xl hover:shadow-md transition-shadow"
                  >
                    <div className="flex justify-between items-start mb-3">
                      <span className="text-sm font-medium text-accent-blue">
                        {citationStyle.toUpperCase()} Citation #{index + 1}
                      </span>
                      <motion.button
                        onClick={() => removeSource(source.id)}
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        className="text-red-500 hover:bg-red-50 p-1 rounded"
                      >
                        <Trash2 className="w-4 h-4" />
                      </motion.button>
                    </div>
                    <p className="text-text-primary text-sm leading-relaxed">
                      {generateCitation(source, citationStyle)}
                    </p>
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default CitationGenerator;
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, AlertCircle, BookOpen, Zap } from 'lucide-react';

const GrammarChecker = () => {
  const [text, setText] = useState('');
  const [errors, setErrors] = useState([]);
  const [isChecking, setIsChecking] = useState(false);
  const [correctedText, setCorrectedText] = useState('');

  const checkGrammar = () => {
    if (!text.trim()) return;
    setIsChecking(true);
    
    setTimeout(() => {
      const mockErrors = [
        { id: 1, type: 'grammar', position: 15, length: 4, original: 'dont', suggestion: "don't", rule: 'Apostrophe missing' },
        { id: 2, type: 'spelling', position: 45, length: 7, original: 'recieve', suggestion: 'receive', rule: 'Spelling error' },
        { id: 3, type: 'punctuation', position: 78, length: 1, original: ',', suggestion: '.', rule: 'Sentence ending' }
      ];
      setErrors(mockErrors);
      setCorrectedText(text.replace(/dont/g, "don't").replace(/recieve/g, 'receive'));
      setIsChecking(false);
    }, 2500);
  };

  const applyCorrection = (error) => {
    const newText = text.replace(error.original, error.suggestion);
    setText(newText);
    setErrors(errors.filter(e => e.id !== error.id));
  };

  const getErrorTypeColor = (type) => {
    switch (type) {
      case 'grammar': return 'text-red-600 bg-red-50 border-red-200';
      case 'spelling': return 'text-blue-600 bg-blue-50 border-blue-200';
      case 'punctuation': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-primary pt-24 pb-16">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold text-text-primary mb-6">Grammar Checker</h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Perfect your writing with AI-powered grammar and spell checking. 
            Get instant corrections and improve your writing quality.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2 bg-white rounded-2xl p-8 shadow-lg"
          >
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-semibold text-text-primary">Your Text</h3>
              <motion.button
                onClick={checkGrammar}
                disabled={!text.trim() || isChecking}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-accent-blue to-accent-green text-white px-6 py-2 rounded-xl font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                <Zap className={`w-4 h-4 ${isChecking ? 'animate-pulse' : ''}`} />
                {isChecking ? 'Checking...' : 'Check Grammar'}
              </motion.button>
            </div>
            
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Type or paste your text here to check for grammar, spelling, and punctuation errors..."
              className="w-full h-96 p-4 border border-gray-200 rounded-xl resize-none focus:ring-2 focus:ring-accent-blue focus:border-transparent transition-all text-lg leading-relaxed"
            />
            
            <div className="flex justify-between items-center mt-4">
              <div className="flex gap-4 text-sm text-text-secondary">
                <span>{text.length} characters</span>
                <span>{text.split(' ').filter(word => word.length > 0).length} words</span>
                <span>{errors.length} issues found</span>
              </div>
              
              {isChecking && (
                <div className="flex items-center gap-2 text-accent-blue">
                  <div className="w-4 h-4 border-2 border-accent-blue border-t-transparent rounded-full animate-spin"></div>
                  <span className="text-sm">Analyzing...</span>
                </div>
              )}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-2xl p-8 shadow-lg"
          >
            <h3 className="text-2xl font-semibold mb-6 text-text-primary flex items-center gap-2">
              <AlertCircle className="w-6 h-6 text-accent-blue" />
              Issues Found
            </h3>
            
            {errors.length === 0 && !isChecking && (
              <div className="text-center py-12">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <p className="text-text-secondary">No issues found! Your text looks great.</p>
              </div>
            )}

            {isChecking && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-4"
              >
                {[1, 2, 3].map((i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-3 bg-gray-100 rounded w-3/4"></div>
                  </div>
                ))}
              </motion.div>
            )}

            <div className="space-y-4">
              {errors.map((error, index) => (
                <motion.div
                  key={error.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`p-4 rounded-xl border-2 ${getErrorTypeColor(error.type)}`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-xs font-medium uppercase tracking-wide">{error.type}</span>
                    <motion.button
                      onClick={() => applyCorrection(error)}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="text-xs bg-white px-2 py-1 rounded-md font-medium hover:shadow-sm transition-all"
                    >
                      Fix
                    </motion.button>
                  </div>
                  <p className="font-medium mb-1">
                    <span className="line-through text-gray-500">{error.original}</span>
                    <span className="mx-2">→</span>
                    <span className="text-green-600">{error.suggestion}</span>
                  </p>
                  <p className="text-sm opacity-75">{error.rule}</p>
                </motion.div>
              ))}
            </div>

            {errors.length > 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="mt-6 pt-6 border-t border-gray-200"
              >
                <div className="flex items-center gap-2 mb-3">
                  <BookOpen className="w-5 h-5 text-accent-blue" />
                  <span className="font-medium text-text-primary">Writing Score</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-gray-200 rounded-full h-3">
                    <motion.div
                      className="bg-gradient-to-r from-red-400 via-yellow-400 to-green-400 h-3 rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.max(20, 100 - errors.length * 15)}%` }}
                      transition={{ duration: 1, ease: 'easeOut' }}
                    ></motion.div>
                  </div>
                  <span className="text-lg font-bold text-text-primary">
                    {Math.max(20, 100 - errors.length * 15)}/100
                  </span>
                </div>
              </motion.div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default GrammarChecker;
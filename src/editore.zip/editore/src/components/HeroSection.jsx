import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, Sparkles } from 'lucide-react';
import SpiderCrawlAnimation from './SpiderCrawlAnimation';

const HeroSection = () => {
  const [currentPhrase, setCurrentPhrase] = useState(0);
  const phrases = [
    'Revolutionize Your Writing',
    'AI Meets Human Creativity',
    'Your Smart Writing Companion'
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentPhrase((prev) => (prev + 1) % phrases.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-primary via-primary to-header">
      {/* Spider Crawl Background Animation */}
      <SpiderCrawlAnimation />
      
      {/* Light Beams */}
      <div className="absolute inset-0 opacity-30">
        <motion.div
          className="absolute top-0 left-1/4 w-1 h-full bg-gradient-to-b from-accent-green/50 to-transparent"
          animate={{
            x: [0, 100, -50, 0],
            opacity: [0.3, 0.7, 0.3]
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'linear'
          }}
        />
        <motion.div
          className="absolute top-0 right-1/3 w-1 h-full bg-gradient-to-b from-accent-blue/50 to-transparent"
          animate={{
            x: [0, -80, 60, 0],
            opacity: [0.3, 0.6, 0.3]
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: 'linear',
            delay: 2
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-24 text-center">
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-full px-6 py-3 mb-8 border border-white/20"
            whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(58, 134, 255, 0.3)' }}
          >
            <Sparkles className="w-5 h-5 text-accent-green" />
            <span className="text-text-primary font-medium">Powered by Advanced AI</span>
          </motion.div>
        </motion.div>

        {/* Animated Headlines */}
        <div className="mb-12 h-32 flex items-center justify-center">
          <AnimatePresence mode="wait">
            <motion.h1
              key={currentPhrase}
              className="text-5xl lg:text-7xl font-bold text-text-primary leading-tight tracking-tight"
              initial={{ opacity: 0, y: 50, rotateX: -90 }}
              animate={{ 
                opacity: 1, 
                y: 0, 
                rotateX: 0,
                textShadow: '0 0 30px rgba(58, 134, 255, 0.3)'
              }}
              exit={{ opacity: 0, y: -50, rotateX: 90 }}
              transition={{ 
                duration: 0.8,
                ease: 'easeInOut'
              }}
            >
              {phrases[currentPhrase]}
            </motion.h1>
          </AnimatePresence>
        </div>

        <motion.p
          className="text-xl lg:text-2xl text-text-secondary mb-12 max-w-3xl mx-auto leading-relaxed"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          Transform your writing with cutting-edge AI technology. From grammar checking to creative assistance, 
          experience the future of intelligent writing tools.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <motion.button
            className="group relative px-8 py-4 bg-gradient-to-r from-accent-blue to-accent-green text-white font-semibold rounded-full overflow-hidden transition-all duration-300"
            whileHover={{ 
              scale: 1.05,
              boxShadow: '0 10px 40px rgba(58, 134, 255, 0.4)'
            }}
            whileTap={{ scale: 0.95 }}
          >
            <span className="relative z-10 flex items-center space-x-2">
              <span>Try Editore Free</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </span>
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-accent-green to-accent-blue opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            />
          </motion.button>

          <motion.button
            className="group px-8 py-4 border-2 border-accent-blue text-accent-blue font-semibold rounded-full hover:bg-accent-blue hover:text-white transition-all duration-300 relative overflow-hidden"
            whileHover={{ 
              scale: 1.05,
              boxShadow: '0 0 20px rgba(58, 134, 255, 0.5)'
            }}
            whileTap={{ scale: 0.95 }}
          >
            <span className="relative z-10">Explore Features</span>
            <motion.div
              className="absolute inset-0 bg-accent-blue opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            />
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
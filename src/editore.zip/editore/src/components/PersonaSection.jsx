import React from 'react';
import { motion } from 'framer-motion';
import { Building2, GraduationCap, BookOpen, ArrowRight } from 'lucide-react';

const PersonaSection = () => {
  const personas = [
    {
      icon: Building2,
      title: 'Businesses',
      description: 'Streamline content creation, ensure brand consistency, and maintain professional communication across all channels.',
      features: ['Brand Voice Consistency', 'Team Collaboration', 'Content Scaling', 'Professional Writing'],
      color: 'from-accent-blue to-accent-green'
    },
    {
      icon: GraduationCap,
      title: 'Educators',
      description: 'Create engaging lesson plans, provide detailed feedback, and help students improve their writing skills effectively.',
      features: ['Lesson Planning', 'Student Feedback', 'Curriculum Support', 'Assessment Tools'],
      color: 'from-accent-green to-accent-blue'
    },
    {
      icon: BookOpen,
      title: 'Students',
      description: 'Improve academic writing, check for plagiarism, and develop better research and citation skills.',
      features: ['Academic Writing', 'Research Support', 'Citation Help', 'Grammar Improvement'],
      color: 'from-purple-500 to-accent-blue'
    }
  ];

  return (
    <section className="py-20 lg:py-32 bg-primary relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-24">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl lg:text-6xl font-bold text-text-primary mb-6 tracking-tight">
            Perfect for Every Writer
          </h2>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto leading-relaxed">
            Whether you're running a business, teaching students, or pursuing academic excellence, 
            Editore adapts to your unique writing needs.
          </p>
        </motion.div>

        {/* Persona Cards */}
        <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
          {personas.map((persona, index) => {
            const Icon = persona.icon;
            
            return (
              <motion.div
                key={persona.title}
                className="group relative bg-card-bg rounded-3xl p-8 shadow-card hover:shadow-card-hover transition-all duration-500 border border-gray-100"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                whileHover={{
                  y: -10,
                  scale: 1.02,
                  boxShadow: '0 20px 40px rgba(0,0,0,0.15)'
                }}
              >
                {/* Glowing Border Effect */}
                <motion.div
                  className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{
                    background: `linear-gradient(135deg, transparent, rgba(58, 134, 255, 0.1), transparent)`,
                    border: '1px solid rgba(58, 134, 255, 0.2)'
                  }}
                />

                {/* Icon */}
                <motion.div
                  className={`w-16 h-16 bg-gradient-to-r ${persona.color} rounded-2xl flex items-center justify-center mb-6 relative z-10`}
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ duration: 0.3 }}
                >
                  <Icon className="w-8 h-8 text-white" />
                  <motion.div
                    className="absolute inset-0 rounded-2xl"
                    animate={{
                      boxShadow: [
                        '0 0 20px rgba(58, 134, 255, 0.3)',
                        '0 0 30px rgba(0, 200, 150, 0.4)',
                        '0 0 20px rgba(58, 134, 255, 0.3)'
                      ]
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: 'easeInOut'
                    }}
                  />
                </motion.div>

                {/* Content */}
                <div className="relative z-10">
                  <h3 className="text-2xl font-bold text-text-primary mb-4">
                    {persona.title}
                  </h3>
                  
                  <p className="text-text-secondary leading-relaxed mb-6">
                    {persona.description}
                  </p>

                  {/* Features List */}
                  <ul className="space-y-3 mb-8">
                    {persona.features.map((feature, featureIndex) => (
                      <motion.li
                        key={feature}
                        className="flex items-center text-text-secondary"
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: (index * 0.2) + (featureIndex * 0.1) }}
                      >
                        <div className="w-2 h-2 bg-gradient-to-r from-accent-blue to-accent-green rounded-full mr-3" />
                        {feature}
                      </motion.li>
                    ))}
                  </ul>

                  {/* CTA Button */}
                  <motion.button
                    className="group/btn flex items-center space-x-2 text-accent-blue font-semibold hover:text-accent-green transition-colors duration-300"
                    whileHover={{ x: 5 }}
                    transition={{ duration: 0.2 }}
                  >
                    <span>Learn More</span>
                    <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform duration-300" />
                  </motion.button>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default PersonaSection;